# SMStoTelegram

Send SMS from Target Device to your Telegram
https://smj.ltd/SMStoTelegram

# Demo:

https://www.youtube.com/watch?v=k2et1O_vFmg

# Contributors

- Syed Mohammed <syedmohmad@gmail.com>
[S.M.J Ltd](https://www.smj.ltd)

# License & copyright

 Syed Mohammed, S.M.J Ltd
 Licensed under the [Apache 2.0 License](LICENSE).
